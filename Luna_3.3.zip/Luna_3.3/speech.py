# -*- coding: utf-8 -*-

from gtts import gTTS

import argparse
import sys, os

#reload(sys)
#sys.setdefaultencoding("utf-8")

parametros = str(sys.argv)

mensagem = parametros.replace("'","")
mensagem_nv1 = mensagem.replace(",","")
mensagem_nv2 = mensagem_nv1.replace("[","")
mensagem_nv3 = mensagem_nv2.replace("]","")
mensagem_nv4 = mensagem_nv3.replace("/etc/luna/speech.py ","")

print(mensagem_nv4)
mytext = mensagem_nv4

language = 'pt-BR'
myobj = gTTS(text=mytext, lang=language, slow=False)
myobj.save("/etc/luna/SYSTEM_FALA.mp3")
os.system("mpg123 /etc/luna/SYSTEM_FALA.mp3")
