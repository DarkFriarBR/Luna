# -*- coding: utf8 -*-

import numpy as np
from netCDF4 import Dataset
import pandas as pd
import glob

def Etopo(lon_area, lat_area, resolution):
### Input
# resolution: resolution of topography for both of longitude and latitude [deg]
# (Original resolution is 0.0167 deg)
# lon_area and lat_area: the region of the map which you want like [100, 130], [20, 25]
###
### Output
# Mesh type longitude, latitude, and topography data
###


# Read NetCDF data
data = Dataset("ETOPO1_Ice_g_gdal.grd", "r")

# Get data
lon_range = data.variables['x_range'][:]
lat_range = data.variables['y_range'][:]
topo_range = data.variables['z_range'][:]
spacing = data.variables['spacing'][:]
dimension = data.variables['dimension'][:]
z = data.variables['z'][:]
lon_num = dimension[0]
lat_num = dimension[1]


###############----For input----###############
file_list = glob.glob("data/query*.csv")
for i in range(len(file_list)):
    eachdata = pd.read_csv(file_list[i])
    if (i == 0):
        data = eachdata
    else:
        data = pd.concat([data, eachdata])

# Data selection
data = data[data.mag >= 5]        

# Change format to datetime for event date
data['np_DateTime']=pd.to_datetime(data['time'].str[:-2],format='%Y-%m-%dT%H:%M:%S')

date = np.array(data['np_DateTime'])
evlon = np.array(data['longitude'])
evlat = np.array(data['latitude'])
evDepth = np.array(data['depth'])
evMag = np.array(data['mag'])

# Calculate time difference
RefTime = np.datetime64("2000-01-01T00:00:00.000000000")
Timefrom_RefTime = (date - RefTime)
# For years
Timefrom_RefYears = Timefrom_RefTime.astype('timedelta64[Y]')
Timefrom_RefYears = Timefrom_RefYears / np.timedelta64(1, 'Y')
