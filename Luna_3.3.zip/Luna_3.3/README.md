![alt text](https://github.com/DarkFriarBR/Luna/blob/main/Luna.jpg)

# Luna A.I. System - Open Source GNU/Linux
```
A Luna ainda esta em desenvolvimento a cada dia!
Aprendendo sempre mais ! :)
```

# Requirements
```
PC - Core 2 Duo
OS - Ubuntu 18.04
Python - Python3
MIC
Speakers
```
# Voice command
```
$ Oi
$ Previsão do tempo para Hoje?
$ Verificar Rede
$ Hora
$ Terremotos
$ Abrir Desktop
$ Abrir Documentos
$ Abrir Música
$ Abrir Imagens
$ Abrir Calculadora
$ Abrir Brownser
$ Abrir Firefox
$ Abrir Chromium
$ Abrir VLC
$ Abrir Facebook
$ Abrir Google
$ Abrir Youtube
$ Pesquisar por * no Google
$ Pesquisar no Google *
$ Pesquisar por * no YouTube
$ Pesquisar no YouTube *
$ Google Maps *
$ Pesquisar por * no Google Maps
$ Pesquisar no Google Maps *
$ Tocar Música
$ Jornal Covid-19
$ Jornal Brasil
$ Jornal Koreia do Norte
$ Jornal *
$ Defina Inteligencia Artificial
$ Quem foi Pero Vaz de Caminha
$ O Que é Ribosomos
```

# Install 
```
$ sudo ./Install.sh

finalizing the installation you can start by calling Luna by:

*** do not need to run as root ***

$ Luna
$ luna
$ Jarvis
$ jarvis
$ Friday
$ friday
$ Sexta
$ sexta
```
