import bs4
import sys
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen
from urllib.request import urlretrieve
from urllib.parse import quote

#qstr = quote("Stanford University")

pesquisa = quote(str(sys.argv))
pesquisa = pesquisa.replace(" ","")
pesquisa = pesquisa.replace("'","")
pesquisa = pesquisa.replace(",","")
pesquisa = pesquisa.replace("[","")
pesquisa = pesquisa.replace("]","")
pesquisa = pesquisa.replace("/etc/luna/googlenews.py","")

#thing = urlretrieve("https://news.google.com/rss/search?search&q=" + pesquisa + "&hl=pt-BR&gl=BR&ceid=BR:pt-419")

#news_url="https://news.google.com/news/rss"
#news_url="https://news.google.com/rss?hl=pt-BR&gl=BR&ceid=BR:pt-419"
#news_url="https://news.google.com/search?q=iraque&hl=pt-BR&gl=BR&ceid=BR%3Apt-419"
#https://news.google.com/rss?search?q=iraque&hl=pt-BR&gl=BR&ceid=BR:pt-419

news_url="https://news.google.com/rss/search?search&q=" + pesquisa  + "&hl=pt-BR&gl=BR&ceid=BR:pt-419"

#news_url = thing

Client=urlopen(news_url)
xml_page=Client.read()
Client.close()

soup_page=soup(xml_page,"xml")
news_list=soup_page.findAll("item")
# Print news title, url and publish date

contador = 10
for c in range(contador):
#for news in news_list:
    print(news_list[c].title.text)
    print(".Próxima Notícia! ")
    #print(news.link.text)
    #print(news.pubDate.text)
    #print("-"*60)

