# -*- coding: utf8 -*-

import aiml
import glob
import time
import argparse
import sys
import os
import gi
from pygame import mixer
from gtts import gTTS
import speech_recognition as sr
import pyaudio

mode = "text"
voice = "pyttsx"
terminate = ['bye', 'buy', 'shutdown', 'exit', 'sair', 'gotosleep', 'goodbye']
bolVerbose = False
lang = "pt-BR"

def falar(jarvis_speech):
    tts = gTTS(text=jarvis_speech, lang='pt-BR', slow=False)
    tts.save("/etc/luna/jarvis_speech.mp3")
    os.system("mpg123 -q /etc/luna/jarvis_speech.mp3")

def falar_offline(jarvis_speech):
    engine = pyttsx.init()
    engine.say(jarvis_speech)
    engine.runAndWait()

def ouvir_microfone():
  microfone = sr.Recognizer()
  with sr.Microphone() as source:
    #Chama a funcao de reducao de ruido disponivel na speech_recognition
    microfone.adjust_for_ambient_noise(source, duration=1)
    #os.system("clear")
    #Avisa ao usuario que esta pronto para ouvir
    os.system("mpg123 -q /etc/luna/Sound/note_start.mp3")
    print("Fale alguma coisa:  ")
    #Armazena a informacao de audio na variavel
    audio = microfone.listen(source, timeout=7)
    
    try:
      #Passa o audio para o reconhecedor de padroes do speech_recognition
      frase = microfone.recognize_google(audio,language='pt-BR')
      #Após alguns segundos, retorna a frase falada
      print("Você disse: " + frase)#Caso nao tenha reconhecido o padrao de fala, exibe esta mensagem
    except sr.UnkownValueError:
      print("Não entendi")
      falar("Não entendi!")
      ouvir_microfone()
    except sr.UnKnownValueError:
      print("Não entendi")
      falar("Não entendi!")
      ouvir_microfone()
    except sr.speech_recognition:
      print("Não entendi")
      falar("Não entendi!")
      ouvir_microfone()
    except Exception as e:
      print("Não entendi")
      falar("Não entendi!")
      ouvir_microfone()
  return frase

_verboseMode = bolVerbose

kernel = aiml.Kernel()
kernel.verbose(bolVerbose)

#if os.path.isfile("bot_brain.brn"):
#kernel.bootstrap(brainFile="/etc/luna/bot_brain.brn")
#else:
kernel.bootstrap(learnFiles="/etc/luna/std-startup.xml", commands="load aiml b")
# kernel.saveBrain("/etc/luna/bot_brain.brn")

# kernel now ready for use
os.system("mpg123 -q /etc/luna/Sound/codecopen.mp3")

while True:
    os.system("clear")
    mensagem = ouvir_microfone()
    #mensagem = input("> ")

    if mensagem == "sair":
        os.system("mpg123 -q /etc/luna/Sound/exit.mp3")
        os.system("clear")
        exit()
    elif mensagem == "salvar":
        kernel.saveBrain("/etc/luna/Brain.brn")
    elif mensagem == "clear":
        os.system("clear")

    jarvis_speech = kernel.respond(mensagem)
    os.system("mpg123 -q /etc/luna/Sound/note_stop.mp3")
    print(">> " + jarvis_speech)
    falar(jarvis_speech)
