# -*- coding: utf8 -*-

import warnings
import sys
import os

warnings.filterwarnings("ignore")

import wikipedia
import random

#value=input("Enter the words: ")
value =str(sys.argv)

value = value.replace("'","")
value = value.replace("[","")
value = value.replace("]","")
value = value.replace(",","")
value = value.replace("/etc/luna/wiki.py ","")

try:
    wikipedia.set_lang("pt")
    m=wikipedia.search(value,2)
    print(wikipedia.summary(m[0],sentences=2))
except wikipedia.exceptions.DisambiguationError as e:
    s=random.choice(e.options)
    p=wikipedia.summary(s,sentences=2)
    print(p)
