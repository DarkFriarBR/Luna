# Luna A.I. System - Open Source GNU/Linux
```
A Luna ainda esta em desenvolvimento a cada dia!
Aprendendo sempre mais ! :)
```

# Requirements
```
PC - Core 2 Duo
OS - Ubuntu 18.04
Python - Python3
MIC
Speakers
```
# Voice command
```
$ Oi
$ Previsão do tempo para Hoje?
$ Verificar Rede
$ Hora
$ Terremotos
$ Jornal Covid-19
$ Jornal Brasil
$ Jornal Koreia do Norte
$ Jornal
$ Defina Inteligencia Artificial
$ Quem foi Pero Vaz de Caminha
$ O Que é Ribosomos
```

# Install 
```
$ sudo ./Install.sh

finalizing the installation you can start by calling Luna by:

*** do not need to run as root ***

$ Luna
$ luna
$ Jarvis
$ jarvis
$ Friday
$ friday
$ Sexta
$ sexta
```
