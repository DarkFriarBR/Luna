#!/bin/bash
#
#===============================================================================
#
# File...........: README.md
# Title..........: Readme from Install
# Program........: Luna Open Source AI -  GNU/Linux
#
# Description....: Basic Text
#
# Copyright......: Copyright(c) 2021 / @DarkFriarBR - HackLab
# License........: GNU GENERAL PUBLIC LICENSE - Version 3, 29 June 2007
#
# Author.........: DarkFriarBR
# E-Mail.........: darkfriarbr@gmail.com
#
# Dependency.....: PC - Core2 Duo, OS - Ubuntu 18.04, MIC - Lapela, Speakers
#                  Python 3
#
# Date...........: 24/04/2021
# Update.........: None
#
# Version........: 0.1.0
#
#===============================================================================
#
# ###########
# # History #
# ###########
#
#     24/04/2021 : Criação do template
#     24/04/2021 : Inicio da documentação e tradução do codigo fonte
#
#===============================================================================

################################################################################
# Apps System
################################################################################

sudo apt install -y libasound2-dev portaudio19-dev libportaudio2 

sudo apt install -y libportaudiocpp0 ffmpeg libasound2-dev

sudo apt install -y python3-pip python3-gi curl mpg123 nmap 

sudo apt install -y jq bc python3-bs4 libxml2-utils ntpdate

################################################################################
# Libs Python
################################################################################

pip3 install argparse
pip3 install aiml
pip3 install SpeechRecognition
pip3 install pyalsaaudio
pip3 install pyttsx
pip3 install pyaudio
pip3 install gTTS
pip3 install pygame
pip3 install BS4
pip3 install BeautifulSoup4
pip3 install wikipedia
pip3 install GoogleNews
pip3 install plotly
pip3 install pandas

################################################################################
# Make Luna 
################################################################################


####################################
# Folders
####################################

sudo mkdir /etc/luna
suod cp -r ./* /etc/luna/

####################################
#  Chmod
####################################
sudo chmod +x /etc/luna/*
sudo chmod +x /etc/luna/*.*
sudo chmod +x /etc/luna/*.sh
sudo chmod +x /etc/luna/*.py

sudo chmod 777 /etc/luna
sudo chmod 777 /etc/luna/*
sudo chmod 777 /etc/luna/*.*

####################################
# Remove old Install
####################################

sudo rm -rf /usr/bin/Luna
sudo rm -rf /usr/bin/luna
sudo rm -rf /usr/bin/Jarvis
sudo rm -rf /usr/bin/jarvis
sudo rm -rf /usr/bin/Sexta
sudo rm -rf /usr/bin/sexta
sudo rm -rf /usr/bin/Friday
sudo rm -rf /usr/bin/friday
sudo rm -rf /usr/bin/Tempo
sudo rm -rf /usr/bin/Tremores
sudo rm -rf /usr/bin/Saudação
sudo rm -rf /usr/bin/Dispositivos
sudo rm -rf /usr/bin/Despedida
sudo rm -rf /usr/bin/Fala
sudo rm -rf /usr/bin/Jornal
sudo rm -rf /usr/bin/Wiki

####################################
# Link a New Install
####################################

sudo ln -s /etc/luna/Luna /usr/bin/Luna
sudo ln -s /etc/luna/Luna /usr/bin/luna
sudo ln -s /etc/luna/Luna /usr/bin/Jarvis
sudo ln -s /etc/luna/Luna /usr/bin/jarvis
sudo ln -s /etc/luna/Luna /usr/bin/Friday
sudo ln -s /etc/luna/Luna /usr/bin/friday
sudo ln -s /etc/luna/Luna /usr/bin/sexta
sudo ln -s /etc/luna/Luna /usr/bin/Sexta

sudo ln -s /etc/luna/Tempo /usr/bin/Tempo
sudo ln -s /etc/luna/Tempo /usr/bin/Climate
sudo ln -s /etc/luna/Tremores /usr/bin/Tremores
sudo ln -s /etc/luna/Tremores /usr/bin/Earthquakes
sudo ln -s /etc/luna/Saudação /usr/bin/Saudação
sudo ln -s /etc/luna/Dispositivos /usr/bin/Dispositivos
sudo ln -s /etc/luna/Despedida /usr/bin/Despedida
sudo ln -s /etc/luna/Fala /usr/bin/Fala
sudo ln -s /etc/luna/GoogleNews /usr/bin/Jornal
sudo ln -s /etc/luna/GoogleNews /usr/bin/News
sudo ln -s /etc/luna/Wiki /usr/bin/Wiki